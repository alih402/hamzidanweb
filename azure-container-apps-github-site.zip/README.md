# Azure Container Apps - Website

A professional landing page built with React to promote Azure Container Apps, ready to be deployed to Azure using Container Apps and Docker.
