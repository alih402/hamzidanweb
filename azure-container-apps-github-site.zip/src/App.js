import React from 'react';

export default function App() {
  return (
    <div className="container">
      <header className="navbar">
        <h1>AZURE CONTAINER APPS</h1>
        <nav>
          <a href="#home" className="active">Home</a>
          <a href="#features">Features</a>
          <a href="#pricing">Pricing</a>
        </nav>
      </header>

      <main className="hero">
        <img src="/azure-icon.png" alt="Azure Container Apps" className="logo" />
        <h2>Azure Container Apps</h2>
        <p className="subtitle">
          Build and deploy modern applications using serverless containers
        </p>
        <p>
          Azure Container Apps is a fully managed serverless container service
          for building and deploying applications. Run microservices and
          containerized applications on a modern platform.
        </p>
        <button className="cta">Get Started</button>
      </main>
    </div>
  );
}
